﻿using System;
using System.IO;
using System.Collections.Generic;

class Program
{
    static int Odbicie(int n)
    {
        char[] cyfry = n.ToString().ToCharArray();
        Array.Reverse(cyfry);
        return int.Parse(new string(cyfry));
    }

class void main()
{
    static int Odbicie(int n)
    {
        char[] cyfry = n.ToString().ToCharArray();
        Array.Reverse(cyfry);
        return int.Parse(new string(cyfry));
    }

    static void Main()
    {
        string[] linie = File.ReadAllLines("liczby.txt");
        int maxRoznica = 0;
        int liczbaMax = 0;

        foreach (string linia in linie)
        {
            int liczba = int.Parse(linia);
            int odb = Odbicie(liczba);
            int roznica = Math.Abs(liczba - odb);
            if (roznica > maxRoznica)
            {
                maxRoznica = roznica;
                liczbaMax = liczba;
            }
        }

        Console.WriteLine("4.2");
        Console.WriteLine($"{liczbaMax} {maxRoznica}");

        using (StreamWriter writer = new StreamWriter("wyniki4.txt", true))
        {
            writer.WriteLine("4.2");
            writer.WriteLine($"{liczbaMax} {maxRoznica}");
        }
    }
}

    static Zadanie4_1()
    {
        string[] linie = File.ReadAllLines("liczby.txt");
        List<int> odbiciaPodzielnePrzez17 = new List<int>();

        foreach (string linia in linie)
        {
            if (int.TryParse(linia, out int liczba))
            {
                int odbicie = Odbicie(liczba);
                if (odbicie % 17 == 0)
                {
                    odbiciaPodzielnePrzez17.Add(odbicie);
                }
            }
        }
        Console.WriteLine("4.1");
        foreach (int odb in odbiciaPodzielnePrzez17)
        {
            Console.WriteLine(odb);
        }
    }
}


class Zadanie4_3
{
    static int Odbicie(int n)
    {
        char[] cyfry = n.ToString().ToCharArray();
        Array.Reverse(cyfry);
        return int.Parse(new string(cyfry));
    }

    static bool CzyPierwsza(int n)
    {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++)
            if (n % i == 0) return false;
        return true;
    }

    static void Main()
    {
        string[] linie = File.ReadAllLines("liczby.txt");

        Console.WriteLine("4.3");
        using (StreamWriter writer = new StreamWriter("wyniki4.txt", true))
        {
            writer.WriteLine("4.3");
            foreach (string linia in linie)
            {
                int liczba = int.Parse(linia);
                int odb = Odbicie(liczba);

                if (CzyPierwsza(liczba) && CzyPierwsza(odb))
                {
                    Console.WriteLine(liczba);
                    writer.WriteLine(liczba);
                }
            }
        }
    }
}
*/