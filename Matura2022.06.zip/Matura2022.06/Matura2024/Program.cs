﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{   //3.2
    static int SkrotLiczba(int liczba)
    {
        int wynik = 0;
        int potega = 1;

        while (liczba > 0)
        {
            int cyfra = liczba % 10;
            if (cyfra % 2 == 1)
            {
                wynik = potega * cyfra + wynik;
                potega *= 10;
            }
            liczba /= 10;
        }

        return wynik;
    }

    static void Main()
    {
        string inputFile = "szybko.txt";
        string outputFile = "wyniki3_2.txt";

        if (!File.Exists(inputFile))
        {
            Console.WriteLine("plik szybko.txt nie istnieje!");
            return;
        }

        List<int> liczby = File.ReadLines(inputFile)
                               .Select(line => int.TryParse(line, out int liczba) ? liczba : -1)
                               .Where(liczba => liczba >= 0)
                               .ToList();

        List<int> bezSkrotu = liczby.Where(liczba => SkrotLiczba(liczba) == 0).ToList();

        if (bezSkrotu.Any())
        {
            int count = bezSkrotu.Count;
            int max = bezSkrotu.Max();
            File.WriteAllText(outputFile, $"{count}\n{max}");
        }
        else
        {
            File.WriteAllText(outputFile, "0\nBrak");
        }

        Console.WriteLine("Zapisano wynik do wyniki3_2.txt");
    }
}
/*        //3.3
class Program1
{
    static void Main()
    {
        string inputFile = "szybko2.txt";
        string outputFile = "wyniki3_3.LXL";

        if (!File.Exists(inputFile))
        {
            Console.WriteLine("Plik wejściowy nie istnieje.");
            return;
        }

        var numbers = File.ReadAllLines(inputFile)
                          .Select(line => int.Parse(line))
                          .ToList();

        using (StreamWriter writer = new StreamWriter(outputFile))
        {
            foreach (int number in numbers)
            {
                 int oddShortcut = FindOddShortcut(number);

                if (GCD(number, oddShortcut) == 7)
                {
                    writer.WriteLine(number);
                }
            }
        }

        Console.WriteLine("Liczenie skonczone. Wyniki zapisano w pliku: " + outputFile);
    }

    static int FindOddShortcut(int number)
    {
        for (int i = 1; i <= number; i += 2)
        {
                if (number % i == 0)
                return i;
        }
        return number;
    }

    static int GCD(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
                b = a % b;
                a = temp;
        }
        return a;
    }
}
*/